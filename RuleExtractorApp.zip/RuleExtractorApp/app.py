# app.py
import streamlit as st
import pandas as pd
from utils.data_preprocessing import preprocess_data
from utils.fake_data import generate_realistic_synthetic_dataset
from utils.rulefit_model import RuleFit
from utils.statistical_analysis import perform_statistical_analysis
from utils.logger import setup_logger

logger = setup_logger(__name__)
st.title("✨ Rule Extractor Web App")

st.sidebar.header("📂 Data Options")
data_option = st.sidebar.radio("Choose an option:", ("Upload CSV", "Generate Fake Data to learn"))

if data_option == "Upload CSV":
    uploaded_file = st.sidebar.file_uploader("Upload your CSV file", type=["csv"])
    if uploaded_file:
        try:
            data = pd.read_csv(uploaded_file)
        except Exception as e:
            st.error(f"Failed to read CSV: {e}")
            st.stop()
    else:
        st.warning("Please upload a CSV")
        st.stop()
else:
    rows = st.sidebar.slider("Number of rows", 10, 20000, 500)
    data = generate_realistic_synthetic_dataset(num_transactions=rows)

st.markdown("### 🔍 Data Preview")
st.dataframe(data.head())

option = st.selectbox("Select action:", ["Exploratory Data Analysis", "Generate Rules"])

if option == "Exploratory Data Analysis":
    drop_columns = st.multiselect("Columns to exclude:", data.columns.tolist())
    if st.button("Perform Analysis"):
        res = perform_statistical_analysis(data, drop_columns=drop_columns)
        st.markdown("#### Numerical Summary"); st.json(res["Numerical Summary"])
        st.markdown("#### Categorical Summary"); st.json(res["Categorical Summary"])
elif option == "Generate Rules":
    drop_columns_from_rules = st.multiselect("Drop columns (ids, tx ids):", data.columns.tolist())
    categorical_custom_columns = st.multiselect("Force categorical:", data.columns.tolist())
    target_col = st.selectbox("Select target column:", data.columns.tolist())
    sample_cap = st.number_input("Sample size cap for RF (interactive):", min_value=1000, max_value=500000, value=20000, step=1000)
    max_rules = st.number_input("Max rules to extract:", min_value=10, max_value=2000, value=200)
    if st.button("Generate Rules"):
        try:
            X, y = preprocess_data(data, target_col, categorical_custom_columns, drop_columns_from_rules, dropna_rows=False)
            rf = RuleFit(tree_size=4, max_rules=int(max_rules), min_support=0.01, sample_size_cap=int(sample_cap), top_n_for_cats=30, n_estimators_cap=100, random_state=42)
            st.info("Fitting rule extractor (this may take a little while)...")
            rf.fit(X, y)
            rules = rf.get_rules()
            st.markdown("### 📜 Generated Rules"); st.dataframe(rules)
            csv = rules.to_csv(index=False); st.download_button("Download rules CSV", csv, file_name="rules.csv", mime="text/csv")
        except Exception as e:
            st.error(f"Error during rule generation: {e}")
