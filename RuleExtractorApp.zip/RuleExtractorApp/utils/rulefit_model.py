# utils/rulefit_model.py
import math, time
from typing import List, Optional, Tuple
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import SGDClassifier
from utils.data_preprocessing import _safe_category_code, _frequency_encode, _topn_collapse

class UniqueList:
    def __init__(self, iterable=None):
        self.items = []
        self.item_set = set()
        if iterable:
            for it in iterable:
                self.add(it)
    def add(self, it):
        if it not in self.item_set:
            self.items.append(it); self.item_set.add(it)
    def __iter__(self): return iter(self.items)
    def __len__(self): return len(self.items)
    def __getitem__(self, i): return self.items[i]

class RuleCondition:
    def __init__(self, feature_index:int, threshold:float, operator:str, support:float, feature_name:Optional[str]=None, is_binary:bool=False):
        self.feature_index = int(feature_index)
        self.threshold = float(threshold) if threshold is not None else None
        self.operator = operator
        self.support = float(support)
        self.feature_name = feature_name
        self.is_binary = is_binary
    def transform(self, X: np.ndarray) -> np.ndarray:
        col = X[:, self.feature_index]
        if self.is_binary:
            return (col == self.threshold).astype(int)
        if self.operator == "<=":
            return (col <= self.threshold).astype(int)
        return (col > self.threshold).astype(int)
    def __str__(self):
        name = self.feature_name if self.feature_name else f"f{self.feature_index}"
        return f"{name} {self.operator} {self.threshold}"

class Rule:
    def __init__(self, rule_conditions: List[RuleCondition], prediction_value:Optional[float]=None):
        self.conditions = UniqueList(rule_conditions)
        self.support = min([c.support for c in rule_conditions]) if rule_conditions else 0.0
        self.prediction_value = prediction_value
    def transform(self, X: np.ndarray) -> np.ndarray:
        if len(self.conditions) == 0:
            return np.ones(X.shape[0], dtype=int)
        mats = [cond.transform(X) for cond in self.conditions]
        out = mats[0].copy()
        for m in mats[1:]:
            out = out * m
        return out
    def __str__(self):
        return " & ".join([str(c) for c in self.conditions])

class RuleEnsemble:
    def __init__(self, tree_list, feature_names:List[str]=None, categorical_features:List[str]=None, max_rules:int=200, min_support:float=0.005):
        self.tree_list = tree_list
        self.feature_names = feature_names or []
        self.categorical_features = categorical_features or []
        self.max_rules = int(max_rules)
        self.min_support = float(min_support)
        self.rules: List[Rule] = []
        self._extract_rules()

    def _extract_rules(self):
        candidates = []
        for tw in self.tree_list:
            tree = tw[0].tree_
            total = float(tree.n_node_samples[0])
            def traverse(node=0, conditions=None):
                if conditions is None: conditions = []
                if tree.children_left[node] != tree.children_right[node]:
                    feat = int(tree.feature[node]); thr = float(tree.threshold[node])
                    left = tree.children_left[node]; right = tree.children_right[node]
                    left_support = tree.n_node_samples[left] / total
                    right_support = tree.n_node_samples[right] / total
                    cond_left = conditions + [RuleCondition(feat, thr, "<=", left_support,
                                        feature_name=(self.feature_names[feat] if feat < len(self.feature_names) else f"f{feat}"),
                                        is_binary=(self.feature_names and (self.feature_names[feat] in self.categorical_features)))]
                    traverse(left, cond_left)
                    cond_right = conditions + [RuleCondition(feat, thr, ">", right_support,
                                        feature_name=(self.feature_names[feat] if feat < len(self.feature_names) else f"f{feat}"),
                                        is_binary=(self.feature_names and (self.feature_names[feat] in self.categorical_features)))]
                    traverse(right, cond_right)
                else:
                    if conditions:
                        est_support = min([c.support for c in conditions])
                        if est_support >= self.min_support:
                            candidates.append(Rule(conditions))
                if len(candidates) >= self.max_rules:
                    return
            traverse()
            if len(candidates) >= self.max_rules: break
        uniq = {}
        for r in candidates:
            k = str(r)
            if k not in uniq: uniq[k] = r
            if len(uniq) >= self.max_rules: break
        self.rules = list(uniq.values())

    def transform_sparse(self, X: np.ndarray) -> csr_matrix:
        n_rows = X.shape[0]; n_rules = len(self.rules)
        if n_rules == 0:
            return csr_matrix((n_rows, 0), dtype=int)
        rows=[]; cols=[]; data=[]
        for j, rule in enumerate(self.rules):
            mask = None
            for cond in rule.conditions:
                vals = X[:, cond.feature_index]
                if cond.is_binary:
                    cmask = (vals == cond.threshold)
                else:
                    cmask = (vals <= cond.threshold) if cond.operator == "<=" else (vals > cond.threshold)
                cmask = np.asarray(cmask, dtype=bool)
                if mask is None: mask = cmask
                else: mask &= cmask
                if not mask.any(): break
            if mask is None: continue
            idxs = np.nonzero(mask)[0]
            if idxs.size>0:
                rows.extend(idxs.tolist()); cols.extend([j]*idxs.size); data.extend([1]*idxs.size)
        if len(data)==0:
            return csr_matrix((n_rows, n_rules), dtype=int)
        return csr_matrix((data, (rows, cols)), shape=(n_rows, n_rules), dtype=int)

class RuleFit:
    def __init__(self, tree_size:int=4, max_rules:int=200, min_support:float=0.01, sample_size_cap:int=50000, top_n_for_cats:int=30, n_estimators_cap:int=100, random_state:Optional[int]=None):
        self.tree_size=int(tree_size); self.max_rules=int(max_rules); self.min_support=float(min_support)
        self.sample_size_cap=int(sample_size_cap); self.top_n_for_cats=int(top_n_for_cats); self.n_estimators_cap=int(n_estimators_cap)
        self.random_state=random_state
        self.feature_names=[]; self.categorical_features=[]; self.rule_ensemble=None; self.selector_clf=None; self.X=None; self.y=None

    def _prepare_inputs(self, X_df: pd.DataFrame) -> Tuple[np.ndarray, List[str], List[str]]:
        X = X_df.copy()
        feature_names=[]; categorical_features=[]; mats=[]
        num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
        for c in num_cols:
            col = pd.to_numeric(X[c], errors='coerce').fillna(0.0).astype('float32')
            mats.append(col.values.reshape(-1,1)); feature_names.append(c)
        cat_cols = X.select_dtypes(include=['object','category']).columns.tolist()
        for c in cat_cols:
            nunique = X[c].nunique(dropna=False)
            if nunique <= 20:
                codes = _safe_category_code(X[c]).astype('float32').reshape(-1,1)
                mats.append(codes); feature_names.append(c); categorical_features.append(c)
            elif nunique <= self.top_n_for_cats:
                codes = _topn_collapse(X[c], n=self.top_n_for_cats).astype('float32').reshape(-1,1)
                mats.append(codes); feature_names.append(c); categorical_features.append(c)
            else:
                freqs = _frequency_encode(X[c]).reshape(-1,1)
                mats.append(freqs); feature_names.append(f"{c}_freq")
        if len(mats)==0:
            mats.append(np.zeros((X.shape[0],1), dtype='float32')); feature_names.append('const')
        X_np = np.hstack(mats).astype('float32')
        return X_np, feature_names, categorical_features

    def _get_sample(self, X_np: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        n_rows = X_np.shape[0]
        if n_rows <= self.sample_size_cap: return X_np, y
        rng = np.random.RandomState(self.random_state)
        unique_y = np.unique(y)
        if len(unique_y)==2:
            idxs=[]; frac = float(self.sample_size_cap)/float(n_rows)
            for val in unique_y:
                pos = np.where(y==val)[0]; k = max(1, int(math.floor(len(pos)*frac)))
                if len(pos)<=k: idxs.extend(pos.tolist())
                else: idxs.extend(rng.choice(pos, size=k, replace=False).tolist())
            idxs = np.array(sorted(set(idxs)), dtype=int); return X_np[idxs], y[idxs]
        else:
            idx = rng.choice(n_rows, size=self.sample_size_cap, replace=False); return X_np[idx], y[idx]

    def fit(self, X, y, feature_names:Optional[List[str]]=None):
        t0 = time.time()
        if isinstance(X, pd.DataFrame):
            self.feature_names_input = list(X.columns)
            X_np, self.feature_names, self.categorical_features = self._prepare_inputs(X)
        else:
            X_np = np.asarray(X).astype('float32')
            self.feature_names = feature_names if feature_names else [f"f{i}" for i in range(X_np.shape[1])]
            self.categorical_features = []
        self.X = X_np; self.y = np.asarray(y)
        X_sample, y_sample = self._get_sample(self.X, self.y)
        n_estimators = max(10, int(math.ceil(float(self.max_rules)/max(1,self.tree_size))))
        n_estimators = min(self.n_estimators_cap, n_estimators)
        rf = RandomForestClassifier(n_estimators=n_estimators, max_leaf_nodes=self.tree_size, max_features='sqrt', n_jobs=-1, random_state=self.random_state, class_weight='balanced')
        t1 = time.time(); rf.fit(X_sample, y_sample); t2 = time.time()
        tree_list = [[est] for est in rf.estimators_]
        self.rule_ensemble = RuleEnsemble(tree_list=tree_list, feature_names=self.feature_names, categorical_features=self.categorical_features, max_rules=self.max_rules, min_support=self.min_support)
        t3 = time.time()
        transformed_sparse = self.rule_ensemble.transform_sparse(X_sample)
        t4 = time.time()
        if transformed_sparse.shape[1] == 0:
            self.selector_clf = None
            return self
        loss_candidates = ['log_loss', 'log']
        clf=None; last_err=None
        for loss_name in loss_candidates:
            try:
                clf = SGDClassifier(loss=loss_name, penalty='l1', max_iter=2000, tol=1e-4, random_state=self.random_state)
                break
            except (TypeError, ValueError) as e:
                last_err = e; continue
        if clf is None:
            try:
                clf = SGDClassifier(loss='modified_huber', penalty='l1', max_iter=2000, tol=1e-4, random_state=self.random_state)
            except Exception as e:
                raise last_err or e
        clf.fit(transformed_sparse, y_sample)
        t5 = time.time()
        self.selector_clf = clf
        self.transformed_sparse_sample = transformed_sparse
        self.fit_time_info = {'rf_fit_s': t2-t1, 'rule_extract_s': t3-t2, 'sparse_build_s': t4-t3, 'sgd_fit_s': t5-t4, 'total_s': time.time()-t0}
        return self

    def get_rules(self, min_support:float=0.001) -> pd.DataFrame:
        if self.rule_ensemble is None or len(self.rule_ensemble.rules)==0:
            return pd.DataFrame(columns=['rule','coef','support','fraud_rate','captured_cases','length'])
        full_sparse = self.rule_ensemble.transform_sparse(self.X)
        if full_sparse.shape[1]==0:
            return pd.DataFrame(columns=['rule','coef','support','fraud_rate','captured_cases','length'])
        coefs = self.selector_clf.coef_.ravel() if self.selector_clf is not None else np.zeros(full_sparse.shape[1])
        n_rows = self.X.shape[0]
        rows_sum = np.array(full_sparse.sum(axis=0)).ravel()
        data=[]
        for i, rule in enumerate(self.rule_ensemble.rules):
            support = float(rows_sum[i])/float(n_rows) if n_rows>0 else 0.0
            if support < min_support: continue
            preds_idx = full_sparse[:, i].nonzero()[0]
            captured_cases = int(np.sum(self.y[preds_idx]==1)) if preds_idx.size>0 else 0
            fraud_rate = float(captured_cases / preds_idx.size) if preds_idx.size>0 else 0.0
            data.append({'rule': str(rule), 'coef': float(coefs[i]) if i<len(coefs) else 0.0, 'support': support, 'fraud_rate': fraud_rate, 'captured_cases': captured_cases, 'length': len(rule.conditions)})
        df = pd.DataFrame(data)
        if df.empty: return df
        df = df.sort_values(by=['coef','support'], ascending=False).reset_index(drop=True)
        return df

    def apply_rules_to_dataframe(self, df: pd.DataFrame, chunk_size: int = 100_000):
        if self.rule_ensemble is None:
            return []
        n = df.shape[0]; counts = np.zeros(len(self.rule_ensemble.rules), dtype=int)
        for start in range(0, n, chunk_size):
            sub = df.iloc[start:start+chunk_size]
            X_sub_np, _, _ = self._prepare_inputs(sub)
            mat = self.rule_ensemble.transform_sparse(X_sub_np)
            counts += np.array(mat.sum(axis=0)).ravel()
        return [{'rule': str(self.rule_ensemble.rules[i]), 'count': int(counts[i])} for i in range(len(self.rule_ensemble.rules))]
