# utils/fake_data.py
from typing import Optional
import pandas as pd
import numpy as np
import random
from faker import Faker
from datetime import datetime, timedelta

def generate_realistic_synthetic_dataset(
    num_transactions: int = 10000,
    fraud_percentage: float = 5,
    outlier_percentage: float = 5,
    return_percentage: float = 3,
    random_state: Optional[int] = 42
) -> pd.DataFrame:
    fake = Faker()
    Faker.seed(random_state)
    np.random.seed(random_state)
    random.seed(random_state)

    customer_profiles = {
        'low_usage': {'freq_mean': 1, 'freq_std': 1, 'amount_mean': 50, 'amount_std': 20},
        'medium_usage': {'freq_mean': 5, 'freq_std': 2, 'amount_mean': 150, 'amount_std': 50},
        'high_usage': {'freq_mean': 10, 'freq_std': 3, 'amount_mean': 500, 'amount_std': 200},
    }
    profile_probabilities = [0.6, 0.3, 0.1]
    product_categories = {
        'Electronics': (300, 2000),
        'Clothing': (20, 300),
        'Groceries': (5, 200),
        'Furniture': (500, 5000),
        'Books': (10, 100),
    }
    locations = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix']
    data = []
    start_date = datetime(2023, 1, 1)
    outlier_count = int(num_transactions * outlier_percentage / 100)
    fraud_count = int(num_transactions * fraud_percentage / 100)

    for i in range(num_transactions):
        transaction_id = f"T{i+1:06}"
        timestamp = start_date + timedelta(minutes=int(np.random.poisson(30)))
        customer_id = f"C{random.randint(1, 1000):05}"
        profile = np.random.choice(list(customer_profiles.keys()), p=profile_probabilities)
        pd_ = customer_profiles[profile]
        trans_freq = max(1, int(np.random.normal(pd_['freq_mean'], pd_['freq_std'])))
        trans_amount = max(0.1, np.random.normal(pd_['amount_mean'], pd_['amount_std']))
        product_category = np.random.choice(list(product_categories.keys()))
        location = random.choice(locations)
        fraud_indicator = 0
        is_return = 1 if random.random() < (return_percentage / 100) else 0

        min_amount, max_amount = product_categories[product_category]
        trans_amount = float(np.clip(trans_amount, min_amount, max_amount))

        if i < outlier_count:
            if random.random() < 0.4:
                trans_freq = random.randint(50, 100)
            if random.random() < 0.4:
                trans_amount = float(random.uniform(10_000, 50_000))
            if random.random() < 0.2:
                product_category = "Luxury Items"
            if random.random() < 0.2:
                location = fake.city()
            if random.random() < 0.3:
                timestamp = start_date + timedelta(seconds=random.randint(0, 100))

        if i >= num_transactions - fraud_count:
            fraud_indicator = 1

        data.append({
            'TransactionID': transaction_id,
            'Timestamp': timestamp,
            'CustomerID': customer_id,
            'ProductCategory': product_category,
            'TransactionAmount': round(trans_amount, 2),
            'TransactionFrequency': trans_freq,
            'Location': location,
            'FraudIndicator': fraud_indicator,
            'IsReturn': is_return
        })

    df = pd.DataFrame(data)
    return df
