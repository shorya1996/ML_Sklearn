import pandas as pd
from utils.data_preprocessing import preprocess_data


def test_preprocess_basic():
    df = pd.DataFrame({"a":[1,2,None], "b":["x","y","z"], "target":[0,1,0]})
    X,y = preprocess_data(df, target_col="target", categorical_custom_columns=["b"], drop_columns_from_rules=[], dropna_rows=False)
    assert "target" not in X.columns
    assert len(y)==3
