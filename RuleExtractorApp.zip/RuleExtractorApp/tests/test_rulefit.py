import pandas as pd
from utils.fake_data import generate_realistic_synthetic_dataset
from utils.rulefit_model import RuleFit

def test_rulefit_runs_small():
    df = generate_realistic_synthetic_dataset(num_transactions=200, fraud_percentage=5, random_state=1)
    X = df.drop(columns=["FraudIndicator"])
    y = df["FraudIndicator"].values
    rf = RuleFit(tree_size=3, max_rules=50, sample_size_cap=100, n_estimators_cap=10, random_state=1)
    model = rf.fit(X, y)
    rules = model.get_rules(min_support=0.001)
    assert isinstance(rules, type(pd.DataFrame()))
