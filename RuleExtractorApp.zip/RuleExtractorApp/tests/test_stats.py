import pandas as pd
from utils.statistical_analysis import perform_statistical_analysis

def test_stats_basic():
    df = pd.DataFrame({"a":[1,2,3,100], "b":[10,11,12,13], "cat":["x","y","x","x"]})
    res = perform_statistical_analysis(df)
    assert "Numerical Summary" in res
    assert res["Outliers Dataset"].shape[0] >= 1
