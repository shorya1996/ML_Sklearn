# Cheque Details Digitizer

This project digitizes cheque fields using image processing and a trained CNN model.