# Train a CNN on MNIST

import torch
import torchvision
... # Full training logic goes here